#!/usr/bin/env bash
JAVA_CMD="java"
$JAVA_CMD -jar "$(dirname "$0")/campus-companion-0.0.1-SNAPSHOT.jar"
